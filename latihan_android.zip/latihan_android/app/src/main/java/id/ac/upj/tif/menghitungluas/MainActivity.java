package id.ac.upj.tif.menghitungluas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView txtHasil;
    EditText txtCurah, txtWaktu;
    Button btnHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtHasil = findViewById(R.id.txtHasil);
        txtCurah = findViewById(R.id.txtCurah);
        txtWaktu = findViewById(R.id.txtWaktu);
        btnHitung = findViewById(R.id.btnHitung);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               double a,b,h,R,tc;

               R = Double.parseDouble(txtCurah.getText().toString());
                tc = Double.parseDouble(txtWaktu.getText().toString());
                a = (R/24);
                b = (24/(tc/60));
                h = Math.pow(b,2);
                double y = Math.cbrt(h);
                double x = a*y;

                txtHasil.setText("Intensitas Hujan : " + x);

                Intent intent = new Intent(getApplicationContext(), Main2Activity.class);
                Bundle c = new Bundle();

                //untuk menyimpan data debit
                String hasil = new Double(x).toString();
                c.putString("Intensitasku", hasil);
                intent.putExtras(c);
                //memulai Activity kedua
                startActivity(intent);
            }
        });

    }
}
