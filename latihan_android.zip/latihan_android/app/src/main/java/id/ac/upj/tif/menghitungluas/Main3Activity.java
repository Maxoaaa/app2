package id.ac.upj.tif.menghitungluas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.text.DecimalFormat;

public class Main3Activity extends AppCompatActivity {
    TextView txtHasil;
    EditText txtManning, txtKemiringan,txtLebarSaluran,txtKedalamanSaluran, txtRangeElevasi;
    Button btnHitung;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        final Bundle b = getIntent().getExtras();
        TextView debit =  findViewById(R.id.namaValue);
        debit.setText(b.getCharSequence("Debitku"));

        txtManning = findViewById(R.id.txtManning);
        txtKemiringan = findViewById(R.id.txtKemiringan);
        txtLebarSaluran = findViewById(R.id.txtLebarSaluran);
        txtKedalamanSaluran = findViewById(R.id.txtKedalamanSaluran);
        txtRangeElevasi = findViewById(R.id.txtRangeElevasi);
        txtHasil = findViewById(R.id.txtHasil);
        btnHitung = findViewById(R.id.btnHitung);

        //untuk tabel
        final TextView ky1 = findViewById(R.id.ky1);
        final TextView kA1 = findViewById(R.id.kA1);
        final TextView kV1 = findViewById(R.id.kV1);
        final TextView kE1 = findViewById(R.id.kE1);
        final TextView kDeltaE2 = findViewById(R.id.kDeltaE2);
        final TextView kR1 = findViewById(R.id.kR1);
        final TextView kSf1 = findViewById(R.id.kSf1);
        final TextView krataSf2 = findViewById(R.id.krataSf2);
        final TextView kdl2 = findViewById(R.id.kdl2);

        final TextView ky2 = findViewById(R.id.ky2);
        final TextView kA2 = findViewById(R.id.kA2);
        final TextView kV2 = findViewById(R.id.kV2);
        final TextView kE2 = findViewById(R.id.kE2);
        final TextView kDeltaE3 = findViewById(R.id.kDeltaE3);
        final TextView kR2 = findViewById(R.id.kR2);
        final TextView kSf2 = findViewById(R.id.kSf2);
        final TextView krataSf3 = findViewById(R.id.krataSf3);
        final TextView kdl3 = findViewById(R.id.kdl3);

        final TextView ky3 = findViewById(R.id.ky3);
        final TextView kA3 = findViewById(R.id.kA3);
        final TextView kV3 = findViewById(R.id.kV3);
        final TextView kE3 = findViewById(R.id.kE3);
        final TextView kDeltaE4 = findViewById(R.id.kDeltaE4);
        final TextView kR3 = findViewById(R.id.kR3);
        final TextView kSf3 = findViewById(R.id.kSf3);
        final TextView krataSf4 = findViewById(R.id.krataSf4);
        final TextView kdl4 = findViewById(R.id.kdl4);

        final TextView ky4 = findViewById(R.id.ky4);
        final TextView kA4 = findViewById(R.id.kA4);
        final TextView kV4 = findViewById(R.id.kV4);
        final TextView kE4 = findViewById(R.id.kE4);
        final TextView kDeltaE5 = findViewById(R.id.kDeltaE5);
        final TextView kR4 = findViewById(R.id.kR4);
        final TextView kSf4 = findViewById(R.id.kSf4);
        final TextView krataSf5 = findViewById(R.id.krataSf5);
        final TextView kdl5 = findViewById(R.id.kdl5);

        final TextView ky5 = findViewById(R.id.ky5);
        final TextView kA5 = findViewById(R.id.kA5);
        final TextView kV5 = findViewById(R.id.kV5);
        final TextView kE5 = findViewById(R.id.kE5);
        final TextView kDeltaE6 = findViewById(R.id.kDeltaE6);
        final TextView kR5 = findViewById(R.id.kR5);
        final TextView kSf5 = findViewById(R.id.kSf5);
        final TextView krataSf6 = findViewById(R.id.krataSf6);
        final TextView kdl6 = findViewById(R.id.kdl6);

        final TextView ky6 = findViewById(R.id.ky6);
        final TextView kA6 = findViewById(R.id.kA6);
        final TextView kV6 = findViewById(R.id.kV6);
        final TextView kE6 = findViewById(R.id.kE6);
        final TextView kR6 = findViewById(R.id.kR6);
        final TextView kSf6 = findViewById(R.id.kSf6);







        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double g = 9.81, range;
                double y1, y2, y3, y4, y5, y6;
                double B, A1, A2, A3, A4, A5, A6;
                double Qs, V1, V2, V3, V4, V5, V6;
                double E1, E2, E3, E4, E5, E6;
                double deltaE2, deltaE3, deltaE4, deltaE5, deltaE6;
                double Rm1, Rm2, Rm3, Rm4, Rm5, Rm6;
                double n,Sf1, Sf2, Sf3, Sf4, Sf5, Sf6;
                double So, dl2, dl3, dl4, dl5 , dl6;


                y1 = Double.parseDouble(txtKedalamanSaluran.getText().toString());
                range = Double.parseDouble(txtRangeElevasi.getText().toString());
                y2 = y1 - range;
                y3 = y2 - range;
                y4 = y3 - range;
                y5 = y4 - range;
                y6 = y5 - range;
                B = Double.parseDouble(txtLebarSaluran.getText().toString());
                A1 = y1 * B;
                A2 = y2 * B;
                A3 = y3 * B;
                A4 = y4 * B;
                A5 = y5 * B;
                A6 = y6 * B;
                Qs = Double.parseDouble( b.getString("Debitku"));
                //Qs = 15;
                V1 = Qs / A1;
                V2 = Qs / A2;
                V3 = Qs / A3;
                V4 = Qs / A4;
                V5 = Qs / A5;
                V6 = Qs / A6;
                E1= y1 +  (Math.pow(V1,2) / (2* g));
                E2= y2 +  (Math.pow(V2,2) / (2* g));
                E3= y3 +  (Math.pow(V3,2) / (2* g));
                E4= y4 +  (Math.pow(V4,2) / (2* g));
                E5= y5 +  (Math.pow(V5,2) / (2* g));
                E6= y6 +  (Math.pow(V6,2) / (2* g));
                deltaE2 = E1 - E2;
                deltaE3 = E2 - E3;
                deltaE4 = E3 - E4;
                deltaE5 = E4 - E5;
                deltaE6 = E5 - E6;

                Rm1 = A1 / (2 * y1  + B );
                Rm2 = A2 / (2 * y2  + B );
                Rm3 = A3 / (2 * y3  + B );
                Rm4 = A4 / (2 * y4  + B );
                Rm5 = A5 / (2 * y5  + B );
                Rm6 = A6 / (2 * y6  + B );
                n = Double.parseDouble(txtManning.getText().toString());

                double R2per3_1 = Math.cbrt(Math.pow(Rm1,2));
                double Sf1temp = (n * Qs) / (A1 * R2per3_1);
                Sf1 = Math.pow(Sf1temp,2);

                double R2per3_2 = Math.cbrt(Math.pow(Rm2,2));
                double Sf2temp = (n * Qs) / (A2 * R2per3_2);
                Sf2 = Math.pow(Sf2temp,2);

                double R2per3_3 = Math.cbrt(Math.pow(Rm3,2));
                double Sf3temp = (n * Qs) / (A3 * R2per3_3);
                Sf3 = Math.pow(Sf3temp,2);

                double R2per3_4 = Math.cbrt(Math.pow(Rm4,2));
                double Sf4temp = (n * Qs) / (A4 * R2per3_4);
                Sf4 = Math.pow(Sf4temp,2);

                double R2per3_5 = Math.cbrt(Math.pow(Rm5,2));
                double Sf5temp = (n * Qs) / (A5 * R2per3_5);
                Sf5 = Math.pow(Sf5temp,2);

                double R2per3_6 = Math.cbrt(Math.pow(Rm6,2));
                double Sf6temp = (n * Qs) / (A6 * R2per3_6);
                Sf6 = Math.pow(Sf6temp,2);

                double rataSf2 = (Sf1 + Sf2) /2;
                double rataSf3 = (Sf2 + Sf3) /2;
                double rataSf4 = (Sf3 + Sf4) /2;
                double rataSf5 = (Sf4 + Sf5) /2;
                double rataSf6 = (Sf5 + Sf6) /2;

                So = Double.parseDouble(txtKemiringan.getText().toString());
                dl2 = deltaE2 / (So - rataSf2);
                dl3 = deltaE3 / (So - rataSf3);
                dl4 = deltaE4 / (So - rataSf4);
                dl5 = deltaE5 / (So - rataSf5);
                dl6 = deltaE6 / (So - rataSf6);

                double Totaldl = (dl2 + dl3 + dl4 + dl5 + dl6) / 5;

                txtHasil.setText("NDL Elevation : "+ Totaldl);
                DecimalFormat precision = new DecimalFormat("#.#################################");

                ky1.setText(precision.format(y1));
                ky2.setText(precision.format(y2));
                ky3.setText(precision.format(y3));
                ky4.setText(precision.format(y4));
                ky5.setText(precision.format(y5));
                ky6.setText(precision.format(y6));

                kA1.setText(precision.format(A1));
                kA2.setText(precision.format(A2));
                kA3.setText(precision.format(A3));
                kA4.setText(precision.format(A4));
                kA5.setText(precision.format(A5));
                kA6.setText(precision.format(A6));

                kV1.setText(precision.format(V1));
                kV2.setText(precision.format(V2));
                kV3.setText(precision.format(V3));
                kV4.setText(precision.format(V4));
                kV5.setText(precision.format(V5));
                kV6.setText(precision.format(V6));

                kE1.setText(precision.format(E1));
                kE2.setText(precision.format(E2));
                kE3.setText(precision.format(E3));
                kE4.setText(precision.format(E4));
                kE5.setText(precision.format(E5));
                kE6.setText(precision.format(E6));

                kR1.setText(precision.format(Rm1));
                kR2.setText(precision.format(Rm2));
                kR3.setText(precision.format(Rm3));
                kR4.setText(precision.format(Rm4));
                kR5.setText(precision.format(Rm5));
                kR6.setText(precision.format(Rm6));

                kSf1.setText(precision.format(Sf1));
                kSf2.setText(precision.format(Sf2));
                kSf3.setText(precision.format(Sf3));
                kSf4.setText(precision.format(Sf4));
                kSf5.setText(precision.format(Sf5));
                kSf6.setText(precision.format(Sf6));

                kDeltaE2.setText(precision.format(deltaE2));
                kDeltaE3.setText(precision.format(deltaE3));
                kDeltaE4.setText(precision.format(deltaE4));
                kDeltaE5.setText(precision.format(deltaE5));
                kDeltaE6.setText(precision.format(deltaE6));

                krataSf2.setText(precision.format(rataSf2));
                krataSf3.setText(precision.format(rataSf3));
                krataSf4.setText(precision.format(rataSf4));
                krataSf5.setText(precision.format(rataSf5));
                krataSf6.setText(precision.format(rataSf6));

                kdl2.setText(precision.format(dl2));
                kdl3.setText(precision.format(dl3));
                kdl4.setText(precision.format(dl4));
                kdl5.setText(precision.format(dl5));
                kdl6.setText(precision.format(dl6));

                //untuk menyimpan data di activity (bundle)
                Intent intent = new Intent(getApplicationContext(), Main4Activity.class);
                Bundle e = new Bundle();
                //untuk menyimpan profil muka air
                String hasil = new Double(Totaldl).toString();
                e.putString("ProfilMukaAir", hasil);
                intent.putExtras(e);
                //memulai Activity ketiga
                startActivity(intent);
            }
        });
    }
}
