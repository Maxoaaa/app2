package id.ac.upj.tif.menghitungluas;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Main4Activity extends AppCompatActivity {
    TextView txtHasil;
    EditText txtLuas;
    Button btnHitung;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        final Bundle b = getIntent().getExtras();
        TextView profil =  findViewById(R.id.namaValue);
        profil.setText(b.getCharSequence("ProfilMukaAir"));

        txtHasil = findViewById(R.id.txtHasil);
        txtLuas = findViewById(R.id.txtluasdas);
        btnHitung = findViewById(R.id.btnHitung);

        btnHitung.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                double L;
                double ndl;

                L = Double.parseDouble(txtLuas.getText().toString());
                ndl = Double.parseDouble( b.getString("ProfilMukaAir"));
                double Volume =  L *ndl;


                txtHasil.setText("Volume Tampung : " + Volume);

            }
        });
    }
}
